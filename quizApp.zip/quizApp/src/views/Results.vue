<template>
   <div>
    <h1>YOUR RESULTS</h1>
    <label>SCORE: </label>
    <label></label>

    <router-link :to='Home'>WANT TO TAKE ANOTHER QUIZ</router-link>
   </div>

</template>
  
  
  <script>

  
  export default {
    name: 'Results',
    components: {
      
    }
  }
  </script>
  
  <style scoped>
  
  </style>
  